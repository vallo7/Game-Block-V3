# Phase 1 — Fondations : notes de migration

Complète `roadmap-definitive-game-block.md` (§5, §6 Phase 1) et `audit-game-block.md`.
Ce paquet contient uniquement les fichiers **nouveaux ou modifiés**. Tout le reste du
projet (images, audio, `capacitor.config.json`, `package.json`, le workflow GitHub
Actions) reste inchangé — copiez ces fichiers par-dessus votre dossier `www/`
existant en remplaçant `www/js/*.js` et `www/css/style.css` par cette nouvelle
arborescence.

**Critère de succès de la phase, tel que défini dans la roadmap : le jeu doit être
identique à aujourd'hui, mais modulaire et testable zone par zone.** Aucune règle de
Classic, aucune formule de score, aucune cadence d'obstacle n'a été modifiée —
uniquement déplacée et réorganisée. Voir la section "Ce qui n'a PAS changé" plus bas.

---

## 1. Nouvelle arborescence

```
www/
├── index.html                  (modifié : <link> CSS ×9, <script type="module"> unique)
├── css/
│   ├── base.css                 variables, reset, boutons, transitions d'écran,
│   │                             animations génériques (scoreBump, popBump, btnPop, celebrate)
│   ├── background.css           fond d'app (2 calques) + décor animé par thème + flash
│   ├── splash.css               écran de lancement
│   ├── menu.css                 menu principal, bouton thème, bouton Remove Ads
│   ├── game.css                 écran de jeu, plateau, combo/praise, quake, halo, confetti
│   ├── overlays.css             pause/réglages, about us, rate us, game over + countdown
│   ├── theme-page.css           carrousel des thèmes visuels
│   ├── tutorial.css             tutoriel de première ouverture + toast pub hors-ligne
│   └── responsive.css           media query petits écrans (chargé en dernier)
└── js/
    ├── config/
    │   └── gameConfig.js         constantes centralisées (grille, couleurs, pub, rate us,
    │                             clés de stockage, timings de fin de partie...)
    ├── core/
    │   ├── game-state.js         état partagé + cycle de vie (init/reset/bindEvents)
    │   ├── game-input.js         tracé du joueur (canAddCell, addCell, cancelPath...)
    │   ├── game-rules.js         règles intouchables (validate, processClears, score,
    │   │                         hasPossibleMove, praise, célébration grille vide)
    │   ├── game-obstacles.js     spawn/cadence/style des blocs de pierre-glace
    │   ├── game-difficulty.js    courbes de difficulté + file d'attente des blocs
    │   ├── game-flow.js          séquence de défaite, countdown, revive, restart animé
    │   ├── game-render.js        tout le rendu Canvas + particules/débris
    │   └── game.js               barrel : assemble les 6 fichiers ci-dessus sur game-state.js
    ├── services/
    │   ├── storage.js, theme.js, audio.js, haptics.js,
    │   ├── settings.js, ads.js, rateus.js, visualtheme.js
    ├── ui/
    │   ├── menu.js, tutorial.js
    └── app.js                    point d'entrée (anciennement js/app.js)
```

L'ancien `js/game.js` (2939 lignes) devient 8 fichiers ; l'ancien `css/style.css`
(~1400 lignes) devient 9 fichiers. Chaque fichier reste petit et à responsabilité
unique — exactement l'objectif "modifiable sans risquer d'endommager le reste".

---

## 2. Comment le split de `Game` reste un seul objet partagé

`core/game-state.js` définit `export const Game = { ...état, ...méthodes de base }`.
Les 6 autres fichiers `core/game-*.js` font :

```js
import { Game } from "./game-state.js";
Object.assign(Game, { maFonction() { ... }, ... });
```

`Game` reste donc **un seul objet**, exactement comme avant — seule son
implémentation est répartie dans plusieurs fichiers. `this` fonctionne normalement
partout (`Game.validate()` a bien `this === Game`), et une fonction de
`game-rules.js` peut appeler `this.spawnParticles(...)` (définie dans
`game-render.js`) sans rien importer de spécial : au moment où le jeu tourne,
`core/game.js` (le barrel) a déjà tout assemblé.

`core/game.js` importe les 6 fichiers uniquement pour leur effet de bord
(`Object.assign`) — c'est lui qu'`app.js` importe pour obtenir un `Game` complet.

---

## 3. Nouveaux emplacements — table de correspondance

### Entrées/événements (ta question sur les "inputs")

| Ancien emplacement (`game.js`) | Nouvel emplacement |
|---|---|
| `bindEvents()` (pointerdown/move/up/cancel sur le canvas, boutons `adsBtn`/`restartBtn`, resize/orientationchange) | `core/game-state.js` |
| `canAddCell`, `tryStart`, `tryContinue`, `addCell`, `backtrackTo`, `cancelPath`, `cancelIncomplete`, `getCellFromEvent`, `invalidFeedback` | `core/game-input.js` |
| `updateHUD`, `renderAvailableBlocks` (pill "cases restantes") | `core/game-input.js` |
| Réglages (checkbox/slider son, musique, vibration) — `bindUI()` | `app.js` (inchangé) |
| Bouton Classic du menu | `ui/menu.js` (inchangé) |
| Tracé scripté du tutoriel | `ui/tutorial.js` (inchangé) |

### Reste du jeu

| Domaine | Fichier |
|---|---|
| État, constantes, cycle de vie, `reset()` | `core/game-state.js` |
| Règles (validate, clears, score, hasPossibleMove, praise) | `core/game-rules.js` |
| Obstacles (spawn, cadence, style pierre/glace) | `core/game-obstacles.js` |
| Difficulté (courbes, file d'attente) | `core/game-difficulty.js` |
| Fin de partie (freeze, countdown, revive, restart) | `core/game-flow.js` |
| Rendu Canvas (tout `draw*`, particules, débris) | `core/game-render.js` |

### Script/CSS dans `index.html`

- `<script src="js/xxx.js">` ×12 → **un seul** `<script type="module" src="js/app.js">`.
  Les imports ES modules se chargent de résoudre le reste de l'arbre de dépendances.
- `<link rel="stylesheet" href="css/style.css">` → 9 `<link>` (voir §1), dans un ordre
  de cascade précis : `responsive.css` reste chargé en dernier pour que ses
  ajustements petits écrans continuent de gagner, exactement comme le `@media` en
  toute fin de l'ancien fichier unique.

---

## 4. `config/gameConfig.js` — ce qui a été centralisé

Valeurs identiques à l'existant, juste regroupées à un seul endroit :

- `GRID.SIZE`, `COLOR_BANK`, `STONE_COLOR`, `ICE_COLOR`
- `EFFECTS_LIMITS` (plafonds particules/débris)
- `OBSTACLES.WARMUP_SECONDS`
- `GAME_OVER` (délais de gel/popup, durée du countdown, circonférence de l'anneau)
- `ADS` (IDs de test AdMob + les 3 probabilités d'interstitiel : entrée Classic 2/3,
  restart 3/4, timeout de défaite 1/2)
- `RATE_US` (URL du store, seuils d'affichage)
- `STORAGE_KEYS` (clés localStorage actuelles + anciennes clés `inkblast_*`)
- `SETTINGS_DEFAULTS`

**Point d'attention volontaire :** les formules elles-mêmes (courbes de difficulté,
cadence d'obstacle, physique des particules) sont restées dans leur fichier de
logique — seuls les *nombres de configuration* ont bougé. Extraire aussi les
coefficients de courbe aurait dépassé le périmètre "aucun changement de
comportement" de la Phase 1 ; ça reste un bon candidat pour la Phase 7 (révision du
système publicitaire) qui prévoit justement de sortir les fréquences du code en dur.

---

## 5. Dépendances circulaires (assumées, sans risque)

Deux paires de modules s'importent mutuellement :

- `core/game-state.js` ↔ `services/ads.js` (Ads a besoin de `Game.pause()/resume()`,
  Game a besoin d'Ads pour ses boutons).
- `app.js` ↔ `ui/menu.js` (Menu a besoin de `App.showGame()`, App a besoin de
  `Menu.init()`).

C'est sans danger ici : dans les deux cas, chaque module ne lit l'autre qu'à
l'intérieur d'un gestionnaire d'événement (donc bien après que tous les modules
aient fini de se charger), jamais au niveau racine du fichier. C'est le même
mécanisme que l'ancien code utilisait déjà implicitement (des objets globaux qui se
référençaient entre eux), simplement rendu explicite par les imports.

Vérifié : l'ensemble du graphe de modules (tous les `core/*`, `services/*`, `ui/*`,
`app.js`) se charge et s'exécute sans erreur sous Node avec des stubs DOM minimaux.

---

## 6. Ce qui n'a PAS changé (garde-fou §1 de la roadmap)

- Grille infinie, formule de score, `revive()`, cadence/pattern des obstacles :
  code déplacé tel quel, zéro ligne de logique réécrite.
- Chaque fonction listée dans `roadmap-definitive-game-block.md §5` est exactement
  là où le tableau de la roadmap la prévoyait ; les quelques fonctions non listées
  explicitement (ex. `pickTurnColor`, `getFillRatio`, `updateHUD`) ont été placées
  au jugé dans le fichier le plus cohérent — un simple déplacement de propriété
  d'objet à objet, sans impact sur le comportement.
- Vérification automatisée effectuée : les 178 propriétés/méthodes de l'ancien
  `Game`, toutes les méthodes des services, et les 43 animations CSS ont été
  retrouvées une fois chacune (aucune manquante, aucune dupliquée) dans les
  nouveaux fichiers.

---

## 7. Prochaine étape

Phase 2 du roadmap (moteur d'environnements) peut maintenant s'appuyer sur cette
base : `services/visualtheme.js` est déjà le point d'entrée désigné pour enrichir
`LIST`/`DECOR` avec des assets par thème, et `core/game-obstacles.js` /
`core/game-render.js` sont les seuls fichiers à toucher pour brancher des blocs et
une grille pilotés par l'environnement actif.
